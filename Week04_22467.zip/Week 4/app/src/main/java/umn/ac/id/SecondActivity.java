package umn.ac.id;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {
    EditText etUbah;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Button btnUbah = (Button) findViewById(R.id.fragment_first_button_berubah);
        final EditText etUbah = findViewById(R.id.fragment_first_edittext_tulisan);
        final TextView tvJadi = findViewById(R.id.fragment_first_textview_tulisan);
        btnUbah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvJadi.setText(etUbah.getText().toString());
            }
        });
    }
}
