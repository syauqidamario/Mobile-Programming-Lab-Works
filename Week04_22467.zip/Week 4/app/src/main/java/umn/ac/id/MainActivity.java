package umn.ac.id;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText etIsian, etUrl;
    private Button btnKirim, btnBrowse,btnPindah;
    TextView tvJawaban;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etIsian = findViewById(R.id.isian);
        etUrl = findViewById(R.id.url);
        btnKirim = findViewById(R.id.buttonKirim);
        btnBrowse = findViewById(R.id.buttonBrowse);
        tvJawaban = findViewById(R.id.jawaban);
        btnPindah = findViewById(R.id.pindah);

        btnKirim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentDua = new Intent(MainActivity.this, Activity_Dua.class);
                String isian = etIsian.getText().toString();
                intentDua.putExtra("PesanDariMain",isian);
                startActivityForResult(intentDua,1);
            }
        });
        btnBrowse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String urltext = etUrl.getText().toString();
                if (urltext.isEmpty()) {
                    urltext = "http://www.umn.ac.id/";
                }
                if (!urltext.contains("www.")){
                    urltext = "www." + urltext;
                }
                if (!urltext.contains("http://")){
                    urltext = "http://"+ urltext;
                }

                Intent browseIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(urltext));
//                browseIntent.setData();
                if (browseIntent.resolveActivity(getPackageManager()) !=null){
                    startActivity(browseIntent);
                }
            }
        });
        btnPindah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentpindah = new Intent(MainActivity.this,FirstActivity.class);
                startActivity(intentpindah);
            }
        });

    }
    @Override
    protected void onActivityResult (int requestCode, int resultCode,Intent data){

        if (resultCode == RESULT_OK){
            String jawaban = data.getStringExtra("Jawaban");
            System.out.println("INI ISI JAWABAN : " + jawaban);
            tvJawaban.setText(jawaban);
        }
        super.onActivityResult (requestCode,requestCode,data);
    }
}
