Cara kerja aplikasi :
Input password + username pada saat login, kemudian cari lagu mana yang ingin diplay, lalu akan muncul halaman
"now playing", dimana lagu bisa dipercepat atau dikembalikan ke waktu semula dengan tombol previous dan tombol next.
Untuk melihat daftar lagu yang diurut secara descending dan ascending, ke menu bagian atas dan cari "Sort Descending"
dan "Sort Ascending", ketika diklik, daftar lagu akan terurut secara ascending dan descending. Untuk keluar dari aplikasi,
silahkan klik logout.